export interface Note {
  id: number;
  text: string;
  urgent?: boolean;
  date: Date;
}
