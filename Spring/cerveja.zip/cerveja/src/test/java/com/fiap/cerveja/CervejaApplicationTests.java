package com.fiap.cerveja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CervejaApplicationTests {

	@Test
	void contextLoads() {
	}

}
